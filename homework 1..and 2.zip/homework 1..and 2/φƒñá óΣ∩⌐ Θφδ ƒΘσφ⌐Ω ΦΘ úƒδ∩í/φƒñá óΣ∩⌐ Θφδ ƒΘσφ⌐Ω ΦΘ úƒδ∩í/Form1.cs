﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace واجب_تغير_لون_الفورم_كل_ثانية
{
    public partial class Form1 : Form
    {
        private Timer timer;
        private Random random;
        public Form1()
        {
            InitializeComponent();
            timer = new Timer();
            timer.Interval= 1000;
            timer.Tick += Form1_Load;

            random = new Random();
            timer.Start();
 
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Color randomColor = Color.FromArgb(
                random.Next(256),
                random.Next(256),
                random.Next(256)
                );
            this.BackColor = randomColor;
           
        }
    }
}
