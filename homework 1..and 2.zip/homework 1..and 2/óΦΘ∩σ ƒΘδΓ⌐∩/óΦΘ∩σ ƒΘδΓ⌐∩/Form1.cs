﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.CodeDom;
using System.Speech.Synthesis;
namespace تكليف_النظري
{
    public partial class Form1 : Form
    {
    
        

        private int step = 5;
        private bool moving = true;

        private string print = " ..............ملاحظة : في هذا الفورم يوجد اكثر من الربعة اسئلة من التكليف ";

        private SpeechSynthesizer synthsizer = new SpeechSynthesizer();
            public Form1()
        {
            InitializeComponent();
            timer1.Interval = 100;
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(0, this.Location.Y);
            butStart.Click += butStart_Click;
            this.Controls.Add(butStart);

            butStop.Click += butStop_Click;
            this.Controls.Add(butStop);

            textBox4.Text = print;
            this.Controls.Add(textBox4);
            timer2.Interval = 200;
            timer2.Start();

            this.KeyPreview = true;     
           
        }

        private void Form1_ResizeEnd(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        //جلب جميع اسماء ادوات الفورم
        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            foreach(Control control in this.Controls)
            {
                if(control != button1 && control != listBox1)
                {
                    listBox1.Items.Add(control.Name);
                }
            }
        }
        //تحريك الشاشة يمين ... يسار
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (moving)
            {
                this.Location = new Point(this.Location.X + step, this.Location.Y);

                if (this.Location.X > Screen.PrimaryScreen.WorkingArea.Width)
                {
                    this.Location = new Point(0, this.Location.Y);
                }
            }
             
        }
        //تحريك الشاشة يمين ... يسار
        private void butStart_Click(object sender, EventArgs e)
        {

            moving = true;
            timer1.Start();

        }
        //تحريك الشاشة يمين ... يسار
        private void butStop_Click(object sender, EventArgs e)
        {
            moving = false;
            timer1.Stop();
        }
        //نص الاخبار عاجل
        private void timer2_Tick(object sender, EventArgs e)
        {

            string current = textBox4.Text;
            if (current.Length > 0)
            {
                current = current.Substring(1) + current[0];
                textBox4.Text = current;

            }

        }
        //الصوات الحروف الانجليزي
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                synthsizer.SpeakAsync(e.KeyChar.ToString());
            }
        }
        //ادخال الارقام فقط
        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox3.Focus();
            }
            else if ((e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9) &&
               (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9) &&
                e.KeyCode != Keys.Back && e.KeyCode != Keys.Delete && e.KeyCode != Keys.Space)
            {
                e.SuppressKeyPress = true;
            }
            
        }
        
        private void butStart_MouseMove(object sender, MouseEventArgs e)
        {
          
        }

        private void textBox1_MouseDown(object sender, MouseEventArgs e)
        {
           
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Enter)
            {
                textBox2.Focus();
            }
        }
        
        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox1.Focus();
            }
        }
        // تحريك ازر في الفورم
        private void button2_MouseMove(object sender, MouseEventArgs e)
        {
            button2.Left += e.X;
            button2.Top += e.Y;
        }
    }
}
